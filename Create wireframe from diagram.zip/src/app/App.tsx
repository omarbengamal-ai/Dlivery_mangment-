import { useState, useMemo, useEffect } from "react";
import {
  LayoutDashboard, Package, Users, BarChart2, Settings, User, LogOut,
  Bell, Search, Plus, ChevronDown, Filter, Download, Eye, Pencil,
  Trash2, XCircle, CheckCircle2, Clock, Phone, MapPin, TrendingUp,
  TrendingDown, DollarSign, ArrowLeft, Printer, Copy, Mic, X,
  AlertTriangle, Calendar, FileText, LayoutGrid, List, Star,
  Shield, Lock, Database, Building2, Car, RefreshCw, MicOff,
  ChevronLeft, ChevronRight, Hash, Truck, Check, AlertCircle,
  Zap, Activity, UserCheck, FileDown, MoreHorizontal, Layers,
  Circle, Wifi, WifiOff, Globe, Info, KeyRound, Bell as BellIcon,
  UploadCloud, BriefcaseBusiness, Sun, Moon
} from "lucide-react";
import {
  LineChart, Line, BarChart, Bar, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
  PieChart, Pie, Cell
} from "recharts";

// ─── Types ────────────────────────────────────────────────────────────────────
type Screen =
  | "login" | "forgot"
  | "dashboard"
  | "orders" | "order-detail"
  | "drivers" | "driver-detail"
  | "reports"
  | "settings"
  | "profile";

type OrderStatus = "pending" | "assigned" | "delivered" | "cancelled";
type DriverStatus = "active" | "inactive" | "busy";
type Modal = "none" | "new-order" | "new-driver" | "confirm-cancel" | "confirm-delete-driver" | "update-status" | "voice-order" | "edit-order" | "edit-driver" | "new-order-voice";

interface Order {
  id: string; customer: string; phone: string; address: string;
  driver: string | null; driverId: string | null; amount: number;
  status: OrderStatus; createdAt: string; notes: string;
}
interface Driver {
  id: string; name: string; phone: string; address: string;
  nationalId: string; vehicleType: string; vehiclePlate: string;
  commission: number; status: DriverStatus; ordersDelivered: number;
  currentOrders: number; totalProfit: number; driverProfit: number;
  rating: number; joinedDate: string;
}

// ─── Mock Data ────────────────────────────────────────────────────────────────
const DRIVERS: Driver[] = [
  { id: "DRV-001", name: "Mohammed Ali", phone: "+966 50 111 2222", address: "Al-Rabwa, Riyadh", nationalId: "1234567890", vehicleType: "Sedan", vehiclePlate: "ABC-1234", commission: 15, status: "busy", ordersDelivered: 142, currentOrders: 3, totalProfit: 18750, driverProfit: 2812, rating: 4.8, joinedDate: "2024-03-15" },
  { id: "DRV-002", name: "Khalid Hassan", phone: "+966 55 222 3333", address: "Al-Madinah Rd, Jeddah", nationalId: "2345678901", vehicleType: "SUV", vehiclePlate: "DEF-5678", commission: 12, status: "busy", ordersDelivered: 98, currentOrders: 2, totalProfit: 12640, driverProfit: 1516, rating: 4.6, joinedDate: "2024-06-01" },
  { id: "DRV-003", name: "Ali Ibrahim", phone: "+966 54 333 4444", address: "Al-Khalidiyah, Dammam", nationalId: "3456789012", vehicleType: "Pickup", vehiclePlate: "GHI-9012", commission: 18, status: "busy", ordersDelivered: 76, currentOrders: 2, totalProfit: 9820, driverProfit: 1767, rating: 4.5, joinedDate: "2024-08-20" },
  { id: "DRV-004", name: "Yusuf Nasser", phone: "+966 56 444 5555", address: "Al-Rawabi, Riyadh", nationalId: "4567890123", vehicleType: "Sedan", vehiclePlate: "JKL-3456", commission: 15, status: "active", ordersDelivered: 113, currentOrders: 0, totalProfit: 14900, driverProfit: 2235, rating: 4.7, joinedDate: "2024-01-10" },
  { id: "DRV-005", name: "Hassan Omar", phone: "+966 50 555 6666", address: "Al-Bawadi, Mecca", nationalId: "5678901234", vehicleType: "Motorcycle", vehiclePlate: "MNO-7890", commission: 20, status: "inactive", ordersDelivered: 54, currentOrders: 0, totalProfit: 6200, driverProfit: 1240, rating: 4.2, joinedDate: "2025-01-05" },
  { id: "DRV-006", name: "Saeed Khalil", phone: "+966 55 666 7777", address: "Al-Malaz, Riyadh", nationalId: "6789012345", vehicleType: "Van", vehiclePlate: "PQR-1234", commission: 10, status: "active", ordersDelivered: 201, currentOrders: 0, totalProfit: 24500, driverProfit: 2450, rating: 4.9, joinedDate: "2023-11-22" },
];

const ORDERS: Order[] = [
  { id: "ORD-2461", customer: "Ahmad Al-Rashidi", phone: "+966 50 123 4567", address: "King Fahd Road, Al-Olaya, Riyadh", driver: "Mohammed Ali", driverId: "DRV-001", amount: 185, status: "delivered", createdAt: "2026-07-14 09:15", notes: "Leave at door" },
  { id: "ORD-2462", customer: "Sara Al-Otaibi", phone: "+966 55 234 5678", address: "Al-Olaya St, Al-Sahafah, Riyadh", driver: "Khalid Hassan", driverId: "DRV-002", amount: 240, status: "assigned", createdAt: "2026-07-14 10:32", notes: "" },
  { id: "ORD-2463", customer: "Faisal Al-Ghamdi", phone: "+966 54 345 6789", address: "Tahlia St, Al-Rawdah, Jeddah", driver: null, driverId: null, amount: 125, status: "pending", createdAt: "2026-07-14 11:05", notes: "Call before delivery" },
  { id: "ORD-2464", customer: "Noura Al-Harbi", phone: "+966 56 456 7890", address: "Prince Sultan Rd, Al-Rakah, Dammam", driver: "Ali Ibrahim", driverId: "DRV-003", amount: 310, status: "delivered", createdAt: "2026-07-14 08:20", notes: "" },
  { id: "ORD-2465", customer: "Omar Al-Zahrani", phone: "+966 50 567 8901", address: "Al-Rawdah District, Riyadh", driver: "Mohammed Ali", driverId: "DRV-001", amount: 95, status: "cancelled", createdAt: "2026-07-14 09:45", notes: "Customer unavailable" },
  { id: "ORD-2466", customer: "Layan Al-Dossari", phone: "+966 55 678 9012", address: "Al-Murjan District, North Jeddah", driver: "Khalid Hassan", driverId: "DRV-002", amount: 420, status: "assigned", createdAt: "2026-07-14 12:10", notes: "" },
  { id: "ORD-2467", customer: "Abdulrahman Saad", phone: "+966 54 789 0123", address: "Al-Nakhil, Riyadh", driver: null, driverId: null, amount: 175, status: "pending", createdAt: "2026-07-14 12:55", notes: "" },
  { id: "ORD-2468", customer: "Hessa Al-Mutairi", phone: "+966 56 890 1234", address: "Al-Shati District, South Jeddah", driver: "Yusuf Nasser", driverId: "DRV-004", amount: 290, status: "delivered", createdAt: "2026-07-14 07:30", notes: "Fragile items" },
  { id: "ORD-2469", customer: "Turki Al-Qahtani", phone: "+966 50 901 2345", address: "Al-Aqiq, Riyadh", driver: "Ali Ibrahim", driverId: "DRV-003", amount: 155, status: "pending", createdAt: "2026-07-14 13:20", notes: "" },
  { id: "ORD-2470", customer: "Maha Al-Shehri", phone: "+966 55 012 3456", address: "Al-Andalus District, Jeddah", driver: "Mohammed Ali", driverId: "DRV-001", amount: 380, status: "delivered", createdAt: "2026-07-14 06:45", notes: "" },
  { id: "ORD-2471", customer: "Bander Al-Sulami", phone: "+966 54 123 4567", address: "Al-Wurud, Riyadh", driver: null, driverId: null, amount: 210, status: "pending", createdAt: "2026-07-14 13:45", notes: "Second floor, no elevator" },
  { id: "ORD-2472", customer: "Reem Al-Anzi", phone: "+966 56 234 5679", address: "Al-Hamra District, Jeddah", driver: "Yusuf Nasser", driverId: "DRV-004", amount: 145, status: "assigned", createdAt: "2026-07-14 14:00", notes: "" },
];

const hourlyData = [
  { h: "06", orders: 3 }, { h: "07", orders: 8 }, { h: "08", orders: 15 },
  { h: "09", orders: 22 }, { h: "10", orders: 18 }, { h: "11", orders: 25 },
  { h: "12", orders: 32 }, { h: "13", orders: 28 }, { h: "14", orders: 20 },
  { h: "15", orders: 16 }, { h: "16", orders: 14 }, { h: "17", orders: 19 },
  { h: "18", orders: 24 }, { h: "19", orders: 21 }, { h: "20", orders: 12 },
];
const weeklyData = [
  { day: "Mon", orders: 142, revenue: 18500 }, { day: "Tue", orders: 168, revenue: 21200 },
  { day: "Wed", orders: 154, revenue: 19800 }, { day: "Thu", orders: 189, revenue: 24600 },
  { day: "Fri", orders: 93, revenue: 12100 }, { day: "Sat", orders: 210, revenue: 27300 },
  { day: "Sun", orders: 176, revenue: 22800 },
];
const monthlyData = [
  { m: "Jan", orders: 3240, revenue: 420000, profit: 75600 },
  { m: "Feb", orders: 2890, revenue: 375700, profit: 67626 },
  { m: "Mar", orders: 3560, revenue: 462800, profit: 83304 },
  { m: "Apr", orders: 4120, revenue: 535600, profit: 96408 },
  { m: "May", orders: 3870, revenue: 503100, profit: 90558 },
  { m: "Jun", orders: 4450, revenue: 578500, profit: 104130 },
  { m: "Jul", orders: 2130, revenue: 277000, profit: 49860 },
];
const driverPerfData = DRIVERS.map(d => ({
  name: d.name.split(" ")[0],
  delivered: d.ordersDelivered,
  profit: d.driverProfit,
  rating: d.rating,
}));
const pieColors = ["#2563EB", "#10B981", "#F59E0B", "#EF4444", "#8B5CF6", "#EC4899"];

// ─── Status Configs ────────────────────────────────────────────────────────────
const statusCfg: Record<OrderStatus, { label: string; tw: string; dot: string }> = {
  pending:   { label: "Pending",   tw: "bg-amber-50  text-amber-700  border-amber-200",  dot: "bg-amber-500" },
  assigned:  { label: "Assigned",  tw: "bg-blue-50   text-blue-700   border-blue-200",   dot: "bg-blue-500" },
  delivered: { label: "Delivered", tw: "bg-emerald-50 text-emerald-700 border-emerald-200", dot: "bg-emerald-500" },
  cancelled: { label: "Cancelled", tw: "bg-red-50    text-red-700    border-red-200",    dot: "bg-red-500" },
};
const driverStatusCfg: Record<DriverStatus, { label: string; tw: string }> = {
  active:   { label: "Available", tw: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  inactive: { label: "Inactive",  tw: "bg-slate-50   text-slate-500   border-slate-200" },
  busy:     { label: "On Duty",   tw: "bg-blue-50    text-blue-700    border-blue-200" },
};

// ─── UI Primitives ────────────────────────────────────────────────────────────

function cn(...cls: (string | boolean | undefined)[]) {
  return cls.filter(Boolean).join(" ");
}

function StatusBadge({ status }: { status: OrderStatus }) {
  const c = statusCfg[status];
  return (
    <span className={cn("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border", c.tw)}>
      <span className={cn("w-1.5 h-1.5 rounded-full", c.dot)} />
      {c.label}
    </span>
  );
}

function DriverBadge({ status }: { status: DriverStatus }) {
  const c = driverStatusCfg[status];
  return (
    <span className={cn("inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border", c.tw)}>
      {c.label}
    </span>
  );
}

function Avatar({ name, size = "md" }: { name: string; size?: "sm" | "md" | "lg" }) {
  const initials = name.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase();
  const colors = ["bg-blue-500", "bg-purple-500", "bg-green-500", "bg-amber-500", "bg-pink-500", "bg-indigo-500"];
  const color = colors[name.charCodeAt(0) % colors.length];
  const sz = size === "sm" ? "w-7 h-7 text-xs" : size === "lg" ? "w-12 h-12 text-base" : "w-9 h-9 text-sm";
  return <div className={cn("rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0", color, sz)}>{initials}</div>;
}

function KPICard({ title, value, sub, icon: Icon, trend, trendVal, color }: {
  title: string; value: string; sub?: string;
  icon: React.ElementType; trend?: "up" | "down" | "neutral"; trendVal?: string; color: string;
}) {
  return (
    <div className="bg-card rounded-xl border border-border p-5 flex flex-col gap-3 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{title}</p>
          <p className="text-2xl font-bold text-foreground mt-1">{value}</p>
          {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
        </div>
        <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center", color)}>
          <Icon size={18} className="text-white" />
        </div>
      </div>
      {trendVal && (
        <div className="flex items-center gap-1">
          {trend === "up" && <TrendingUp size={13} className="text-emerald-600" />}
          {trend === "down" && <TrendingDown size={13} className="text-red-500" />}
          <span className={cn("text-xs font-medium", trend === "up" ? "text-emerald-600" : trend === "down" ? "text-red-500" : "text-muted-foreground")}>
            {trendVal}
          </span>
          <span className="text-xs text-muted-foreground">vs last period</span>
        </div>
      )}
    </div>
  );
}

function SectionTitle({ title, sub }: { title: string; sub?: string }) {
  return (
    <div>
      <h2 className="text-base font-semibold text-foreground">{title}</h2>
      {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
    </div>
  );
}

function EmptyState({ icon: Icon, title, sub, action, onAction }: {
  icon: React.ElementType; title: string; sub: string; action?: string; onAction?: () => void;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 gap-3">
      <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center">
        <Icon size={24} className="text-muted-foreground" />
      </div>
      <p className="text-sm font-medium text-foreground">{title}</p>
      <p className="text-xs text-muted-foreground">{sub}</p>
      {action && <button onClick={onAction} className="mt-2 px-4 py-2 bg-primary text-primary-foreground text-xs font-medium rounded-lg hover:bg-blue-700 transition-colors">{action}</button>}
    </div>
  );
}

function TableCell({ children, className }: { children: React.ReactNode; className?: string }) {
  return <td className={cn("px-4 py-3 text-sm", className)}>{children}</td>;
}
function TableHead({ children, className }: { children: React.ReactNode; className?: string }) {
  return <th className={cn("px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide", className)}>{children}</th>;
}

function Pagination({ page, total, perPage, onChange }: { page: number; total: number; perPage: number; onChange: (p: number) => void }) {
  const pages = Math.ceil(total / perPage);
  return (
    <div className="flex items-center justify-between px-4 py-3 border-t border-border">
      <p className="text-xs text-muted-foreground">Showing {Math.min((page - 1) * perPage + 1, total)}–{Math.min(page * perPage, total)} of {total} results</p>
      <div className="flex items-center gap-1">
        <button onClick={() => onChange(page - 1)} disabled={page === 1} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed transition-colors"><ChevronLeft size={14} /></button>
        {Array.from({ length: pages }, (_, i) => i + 1).map(p => (
          <button key={p} onClick={() => onChange(p)} className={cn("w-8 h-8 rounded-lg text-xs font-medium transition-colors", p === page ? "bg-primary text-white" : "hover:bg-muted text-foreground")}>{p}</button>
        ))}
        <button onClick={() => onChange(page + 1)} disabled={page === pages} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed transition-colors"><ChevronRight size={14} /></button>
      </div>
    </div>
  );
}

// ─── Modal Shell ──────────────────────────────────────────────────────────────
function ModalShell({ title, sub, onClose, children, width = "max-w-xl" }: {
  title: string; sub?: string; onClose: () => void; children: React.ReactNode; width?: string;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(15,23,42,0.45)" }}>
      <div className={cn("bg-card rounded-2xl shadow-2xl border border-border w-full", width)} onClick={e => e.stopPropagation()}>
        <div className="flex items-start justify-between p-6 border-b border-border">
          <div>
            <h3 className="text-base font-semibold text-foreground">{title}</h3>
            {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-muted flex items-center justify-center transition-colors"><X size={16} /></button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}

function FormRow({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-xs font-medium text-foreground">{label}{required && <span className="text-red-500 ml-0.5">*</span>}</label>
      {children}
    </div>
  );
}

function Input({ placeholder, value, onChange, type = "text", mono }: {
  placeholder?: string; value?: string; onChange?: (v: string) => void; type?: string; mono?: boolean;
}) {
  return (
    <input
      type={type}
      placeholder={placeholder}
      value={value ?? ""}
      onChange={e => onChange?.(e.target.value)}
      className={cn(
        "w-full px-3 py-2 rounded-lg border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground",
        "focus:outline-none focus:ring-2 focus:ring-ring focus:border-primary transition-colors",
        mono && "font-mono"
      )}
    />
  );
}

function Select({ children, value, onChange }: { children: React.ReactNode; value?: string; onChange?: (v: string) => void }) {
  return (
    <select
      value={value}
      onChange={e => onChange?.(e.target.value)}
      className="w-full px-3 py-2 rounded-lg border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-primary transition-colors appearance-none"
    >
      {children}
    </select>
  );
}

function Textarea({ placeholder, rows = 3 }: { placeholder?: string; rows?: number }) {
  return (
    <textarea
      placeholder={placeholder}
      rows={rows}
      className="w-full px-3 py-2 rounded-lg border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-primary resize-none transition-colors"
    />
  );
}

function BtnPrimary({ children, onClick, icon: Icon, disabled }: { children: React.ReactNode; onClick?: () => void; icon?: React.ElementType; disabled?: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
    >
      {Icon && <Icon size={15} />}
      {children}
    </button>
  );
}

function BtnSecondary({ children, onClick, icon: Icon }: { children: React.ReactNode; onClick?: () => void; icon?: React.ElementType }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-2 px-4 py-2 bg-card text-foreground text-sm font-medium rounded-lg border border-border hover:bg-muted transition-colors"
    >
      {Icon && <Icon size={15} />}
      {children}
    </button>
  );
}

function BtnDanger({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  return (
    <button onClick={onClick} className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700 transition-colors">
      {children}
    </button>
  );
}

// ─── New Order Modal ──────────────────────────────────────────────────────────
function NewOrderModal({ onClose, preTab }: { onClose: () => void; preTab?: "manual" | "voice" }) {
  const [tab, setTab] = useState<"manual" | "voice">(preTab ?? "manual");
  const [recording, setRecording] = useState(false);
  const [processed, setProcessed] = useState(false);

  return (
    <ModalShell title="New Order" sub="Create a new delivery order" onClose={onClose} width="max-w-lg">
      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-muted rounded-lg mb-6">
        {(["manual", "voice"] as const).map(t => (
          <button key={t} onClick={() => setTab(t)} className={cn("flex-1 flex items-center justify-center gap-2 py-2 rounded-md text-sm font-medium transition-colors", tab === t ? "bg-card shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground")}>
            {t === "manual" ? <FileText size={14} /> : <Mic size={14} />}
            {t === "manual" ? "Manual Entry" : "Voice Input"}
          </button>
        ))}
      </div>

      {tab === "manual" && (
        <div className="flex flex-col gap-4">
          <div className="grid grid-cols-2 gap-4">
            <FormRow label="Customer Name" required><Input placeholder="Full name" /></FormRow>
            <FormRow label="Phone" required><Input placeholder="+966 5X XXX XXXX" /></FormRow>
          </div>
          <FormRow label="Delivery Address" required><Input placeholder="Street, District, City" /></FormRow>
          <div className="grid grid-cols-2 gap-4">
            <FormRow label="Order Amount (SAR)" required><Input placeholder="0.00" mono /></FormRow>
            <FormRow label="Assign Driver">
              <Select>
                <option value="">— Unassigned —</option>
                {DRIVERS.filter(d => d.status !== "inactive").map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
              </Select>
            </FormRow>
          </div>
          <FormRow label="Notes"><Textarea placeholder="Any special delivery instructions…" /></FormRow>
          <div className="flex justify-end gap-3 pt-2 border-t border-border">
            <BtnSecondary onClick={onClose}>Cancel</BtnSecondary>
            <BtnPrimary icon={Check}>Save Order</BtnPrimary>
          </div>
        </div>
      )}

      {tab === "voice" && (
        <div className="flex flex-col items-center gap-6">
          {!processed ? (
            <>
              <div className={cn("w-24 h-24 rounded-full border-4 flex items-center justify-center cursor-pointer transition-all", recording ? "border-red-500 bg-red-50 animate-pulse" : "border-primary bg-accent")} onClick={() => { setRecording(!recording); if (recording) setTimeout(() => setProcessed(true), 800); }}>
                {recording ? <MicOff size={32} className="text-red-600" /> : <Mic size={32} className="text-primary" />}
              </div>
              <div className="text-center">
                <p className="text-sm font-medium text-foreground">{recording ? "Recording… tap to stop" : "Tap microphone to start recording"}</p>
                <p className="text-xs text-muted-foreground mt-1">Say the customer name, phone, address and amount</p>
              </div>
              {recording && (
                <div className="flex gap-1 items-end h-8">
                  {[3, 6, 4, 8, 5, 7, 4, 6, 3, 5].map((h, i) => (
                    <div key={i} className="w-1.5 rounded-full bg-primary" style={{ height: `${h * 3}px`, animationDelay: `${i * 0.1}s` }} />
                  ))}
                </div>
              )}
            </>
          ) : (
            <div className="w-full flex flex-col gap-4">
              <div className="flex items-center gap-2 text-emerald-700 bg-emerald-50 rounded-lg px-4 py-3 text-sm font-medium border border-emerald-200">
                <CheckCircle2 size={16} /> Voice processed — please review and confirm
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormRow label="Customer Name"><Input value="Faisal Al-Mansour" /></FormRow>
                <FormRow label="Phone"><Input value="+966 54 812 3344" mono /></FormRow>
              </div>
              <FormRow label="Address"><Input value="Al-Nakhil District, Riyadh" /></FormRow>
              <div className="grid grid-cols-2 gap-4">
                <FormRow label="Amount (SAR)"><Input value="220" mono /></FormRow>
                <FormRow label="Assign Driver"><Select><option value="">— Unassigned —</option>{DRIVERS.filter(d => d.status !== "inactive").map(d => <option key={d.id}>{d.name}</option>)}</Select></FormRow>
              </div>
              <div className="flex justify-end gap-3 pt-2 border-t border-border">
                <BtnSecondary onClick={() => setProcessed(false)}>Re-record</BtnSecondary>
                <BtnPrimary icon={Check}>Confirm Order</BtnPrimary>
              </div>
            </div>
          )}
        </div>
      )}
    </ModalShell>
  );
}

// ─── New Driver Modal ─────────────────────────────────────────────────────────
function NewDriverModal({ onClose }: { onClose: () => void }) {
  return (
    <ModalShell title="Add New Driver" sub="Enter driver details and vehicle information" onClose={onClose} width="max-w-2xl">
      <div className="flex flex-col gap-4">
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Personal Information</p>
        <div className="grid grid-cols-2 gap-4">
          <FormRow label="Full Name" required><Input placeholder="Driver full name" /></FormRow>
          <FormRow label="Phone" required><Input placeholder="+966 5X XXX XXXX" /></FormRow>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <FormRow label="National ID" required><Input placeholder="10-digit ID" mono /></FormRow>
          <FormRow label="Address"><Input placeholder="District, City" /></FormRow>
        </div>
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider pt-2 border-t border-border">Vehicle Information</p>
        <div className="grid grid-cols-3 gap-4">
          <FormRow label="Vehicle Type" required>
            <Select><option>Sedan</option><option>SUV</option><option>Pickup</option><option>Motorcycle</option><option>Van</option></Select>
          </FormRow>
          <FormRow label="Plate Number" required><Input placeholder="ABC-1234" mono /></FormRow>
          <FormRow label="Commission %" required><Input placeholder="15" mono /></FormRow>
        </div>
        <FormRow label="Status">
          <Select><option value="active">Active</option><option value="inactive">Inactive</option></Select>
        </FormRow>
        <div className="flex justify-end gap-3 pt-4 border-t border-border">
          <BtnSecondary onClick={onClose}>Cancel</BtnSecondary>
          <BtnPrimary icon={Check}>Save Driver</BtnPrimary>
        </div>
      </div>
    </ModalShell>
  );
}

// ─── Confirm Dialog ───────────────────────────────────────────────────────────
function ConfirmDialog({ title, sub, message, onClose, onConfirm, variant = "danger" }: {
  title: string; sub?: string; message: string; onClose: () => void; onConfirm: () => void; variant?: "danger" | "warning";
}) {
  return (
    <ModalShell title={title} sub={sub} onClose={onClose} width="max-w-sm">
      <div className="flex flex-col gap-5">
        <div className={cn("rounded-xl p-4 flex gap-3 text-sm", variant === "danger" ? "bg-red-50 border border-red-100 text-red-700" : "bg-amber-50 border border-amber-100 text-amber-700")}>
          <AlertTriangle size={16} className="flex-shrink-0 mt-0.5" />
          <p>{message}</p>
        </div>
        {variant === "danger" && (
          <FormRow label="Reason (optional)">
            <Select><option value="">Select a reason</option><option>Customer request</option><option>Wrong address</option><option>Driver unavailable</option><option>Item unavailable</option><option>Other</option></Select>
          </FormRow>
        )}
        <div className="flex justify-end gap-3">
          <BtnSecondary onClick={onClose}>Go Back</BtnSecondary>
          {variant === "danger" ? <BtnDanger onClick={onConfirm}>Yes, Confirm</BtnDanger> : <BtnPrimary onClick={onConfirm}>Confirm</BtnPrimary>}
        </div>
      </div>
    </ModalShell>
  );
}

// ─── Update Status Modal ──────────────────────────────────────────────────────
function UpdateStatusModal({ order, onClose }: { order: Order; onClose: () => void }) {
  const [selected, setSelected] = useState<OrderStatus>(order.status);
  const steps: OrderStatus[] = ["pending", "assigned", "delivered", "cancelled"];
  return (
    <ModalShell title="Update Order Status" sub={`Order ${order.id}`} onClose={onClose} width="max-w-sm">
      <div className="flex flex-col gap-4">
        {steps.map((s, i) => (
          <button key={s} onClick={() => setSelected(s)} className={cn("flex items-center gap-3 p-3 rounded-xl border text-sm font-medium transition-colors", selected === s ? "border-primary bg-accent text-primary" : "border-border hover:bg-muted")}>
            <div className={cn("w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold", selected === s ? "bg-primary" : "bg-muted text-muted-foreground")}>{i + 1}</div>
            <div className="text-left">
              <p className="font-medium">{statusCfg[s].label}</p>
              <p className="text-xs text-muted-foreground font-normal">{s === "pending" ? "Waiting for driver assignment" : s === "assigned" ? "Driver is on the way" : s === "delivered" ? "Package delivered successfully" : "Order cancelled"}</p>
            </div>
            {selected === s && <Check size={16} className="ml-auto text-primary" />}
          </button>
        ))}
        <div className="flex justify-end gap-3 pt-2 border-t border-border">
          <BtnSecondary onClick={onClose}>Cancel</BtnSecondary>
          <BtnPrimary onClick={onClose}>Update Status</BtnPrimary>
        </div>
      </div>
    </ModalShell>
  );
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────
const NAV = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "orders",    label: "Orders",    icon: Package, badge: 5 },
  { id: "drivers",   label: "Drivers",   icon: Car },
  { id: "reports",   label: "Reports",   icon: BarChart2 },
  { id: "settings",  label: "Settings",  icon: Settings },
];

function Sidebar({ screen, setScreen }: { screen: Screen; setScreen: (s: Screen) => void }) {
  const active = NAV.find(n => screen.startsWith(n.id));
  return (
    <aside className="w-[220px] min-h-screen bg-card border-r border-border flex flex-col flex-shrink-0">
      {/* Logo */}
      <div className="h-[60px] flex items-center gap-3 px-5 border-b border-border">
        <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
          <Truck size={16} className="text-white" />
        </div>
        <div>
          <p className="text-sm font-bold text-foreground leading-tight">DeliverOS</p>
          <p className="text-[10px] text-muted-foreground">Management System</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 flex flex-col gap-1">
        {NAV.map(({ id, label, icon: Icon, badge }) => {
          const isActive = active?.id === id;
          return (
            <button
              key={id}
              onClick={() => setScreen(id as Screen)}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all group",
                isActive ? "bg-accent text-primary" : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              <Icon size={17} className={isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"} />
              {label}
              {badge && <span className="ml-auto text-[10px] font-bold bg-primary text-white rounded-full px-1.5 py-0.5">{badge}</span>}
            </button>
          );
        })}
      </nav>

      {/* User */}
      <div className="px-3 pb-4 border-t border-border pt-3">
        <button onClick={() => setScreen("profile")} className={cn("w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors group", screen === "profile" ? "bg-accent text-primary" : "text-muted-foreground hover:bg-muted hover:text-foreground")}>
          <Avatar name="Nasser Al-Qahtani" size="sm" />
          <div className="text-left">
            <p className="text-xs font-semibold text-foreground">Nasser Al-Qahtani</p>
            <p className="text-[10px] text-muted-foreground">System Manager</p>
          </div>
        </button>
      </div>
    </aside>
  );
}

// ─── Top Bar ──────────────────────────────────────────────────────────────────
function TopBar({ title, breadcrumb, onBack, actions, dark, onToggleDark }: {
  title: string; breadcrumb?: string[]; onBack?: () => void; actions?: React.ReactNode;
  dark: boolean; onToggleDark: () => void;
}) {
  const [notifs] = useState(3);
  return (
    <header className="h-[60px] flex items-center justify-between px-6 border-b border-border bg-card flex-shrink-0">
      <div className="flex items-center gap-3">
        {onBack && <button onClick={onBack} className="w-8 h-8 rounded-lg hover:bg-muted flex items-center justify-center transition-colors"><ArrowLeft size={16} /></button>}
        <div>
          {breadcrumb && <p className="text-[10px] text-muted-foreground">{breadcrumb.join(" / ")}</p>}
          <h1 className="text-sm font-semibold text-foreground">{title}</h1>
        </div>
      </div>
      <div className="flex items-center gap-2">
        {actions}
        {/* Dark mode toggle */}
        <button
          onClick={onToggleDark}
          className="w-9 h-9 rounded-lg hover:bg-muted flex items-center justify-center transition-colors"
          title={dark ? "Switch to Light Mode" : "Switch to Dark Mode"}
        >
          {dark
            ? <Sun size={17} className="text-amber-400" />
            : <Moon size={17} className="text-muted-foreground" />
          }
        </button>
        <button className="relative w-9 h-9 rounded-lg hover:bg-muted flex items-center justify-center transition-colors">
          <Bell size={17} className="text-muted-foreground" />
          {notifs > 0 && <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-red-500" />}
        </button>
        <div className="w-px h-6 bg-border mx-1" />
        <div className="flex items-center gap-2">
          <Avatar name="Nasser Al-Qahtani" size="sm" />
          <span className="text-xs font-medium text-foreground hidden lg:block">Nasser</span>
        </div>
      </div>
    </header>
  );
}

// ─── Login Screen ─────────────────────────────────────────────────────────────
function LoginScreen({ onLogin, setScreen }: { onLogin: () => void; setScreen: (s: Screen) => void }) {
  return (
    <div className="min-h-screen bg-background flex">
      {/* Left panel */}
      <div className="flex-1 bg-primary hidden lg:flex flex-col justify-between p-12">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center">
            <Truck size={18} className="text-white" />
          </div>
          <span className="text-white font-bold text-lg">DeliverOS</span>
        </div>
        <div>
          <p className="text-white/80 text-sm font-medium uppercase tracking-widest mb-4">Internal Platform</p>
          <h2 className="text-white text-4xl font-bold leading-tight mb-4">Manage every delivery,<br />from one dashboard.</h2>
          <p className="text-white/70 text-sm leading-relaxed max-w-sm">Track orders in real-time, manage your driver fleet, and generate detailed reports — all in one professional system.</p>
        </div>
        <div className="flex gap-8">
          {[["12,480+", "Orders Processed"], ["98.2%", "Delivery Rate"], ["6", "Active Drivers"]].map(([v, l]) => (
            <div key={l}>
              <p className="text-white text-xl font-bold">{v}</p>
              <p className="text-white/60 text-xs">{l}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Right panel */}
      <div className="w-full lg:w-[480px] flex items-center justify-center p-8">
        <div className="w-full max-w-sm">
          <div className="flex items-center gap-2 mb-10 lg:hidden">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Truck size={15} className="text-white" />
            </div>
            <span className="font-bold text-foreground">DeliverOS</span>
          </div>

          <h2 className="text-2xl font-bold text-foreground mb-1">Welcome back</h2>
          <p className="text-sm text-muted-foreground mb-8">Sign in to your manager account</p>

          <div className="flex flex-col gap-4">
            <FormRow label="Email address">
              <Input type="email" placeholder="manager@company.com" />
            </FormRow>
            <FormRow label="Password">
              <Input type="password" placeholder="••••••••••" />
            </FormRow>
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <div className="w-4 h-4 rounded border border-border bg-card" />
                <span className="text-xs text-muted-foreground">Remember me</span>
              </label>
              <button onClick={() => setScreen("forgot")} className="text-xs text-primary hover:underline font-medium">Forgot password?</button>
            </div>
            <button onClick={onLogin} className="w-full py-2.5 bg-primary text-white font-semibold text-sm rounded-xl hover:bg-blue-700 transition-colors mt-2">
              Sign In
            </button>
          </div>

          <p className="text-xs text-muted-foreground text-center mt-8">Delivery Management System v2.4.1 — Internal Use Only</p>
        </div>
      </div>
    </div>
  );
}

// ─── Forgot Password Screen ───────────────────────────────────────────────────
function ForgotScreen({ setScreen }: { setScreen: (s: Screen) => void }) {
  const [sent, setSent] = useState(false);
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="w-full max-w-sm bg-card rounded-2xl border border-border p-8 shadow-lg">
        <button onClick={() => setScreen("login")} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground mb-6 transition-colors">
          <ChevronLeft size={14} /> Back to login
        </button>
        {!sent ? (
          <>
            <div className="w-12 h-12 bg-accent rounded-xl flex items-center justify-center mb-5">
              <KeyRound size={20} className="text-primary" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-1">Forgot password?</h2>
            <p className="text-sm text-muted-foreground mb-6">Enter your email and we will send you a reset link.</p>
            <div className="flex flex-col gap-4">
              <FormRow label="Email address"><Input type="email" placeholder="manager@company.com" /></FormRow>
              <button onClick={() => setSent(true)} className="w-full py-2.5 bg-primary text-white font-semibold text-sm rounded-xl hover:bg-blue-700 transition-colors">
                Send Reset Link
              </button>
            </div>
          </>
        ) : (
          <div className="text-center">
            <div className="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center mx-auto mb-5">
              <CheckCircle2 size={24} className="text-emerald-600" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">Check your inbox</h2>
            <p className="text-sm text-muted-foreground mb-6">We sent a password reset link to your email address. It expires in 30 minutes.</p>
            <button onClick={() => setScreen("login")} className="w-full py-2.5 bg-primary text-white font-semibold text-sm rounded-xl hover:bg-blue-700 transition-colors">
              Return to Login
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Dashboard Screen ─────────────────────────────────────────────────────────
function DashboardScreen({ setScreen, openModal }: { setScreen: (s: Screen) => void; openModal: (m: Modal) => void }) {
  const todayOrders = ORDERS.filter(o => o.status !== "cancelled").length;
  const totalRevenue = ORDERS.reduce((s, o) => s + o.amount, 0);

  const kpis = [
    { title: "Total Orders",    value: "12,480",  sub: "All time",          icon: Package,        trend: "up" as const,   trendVal: "+8.2%", color: "bg-blue-500" },
    { title: "Today's Orders",  value: String(todayOrders),  sub: "July 14, 2026",  icon: Zap,           trend: "up" as const,   trendVal: "+12%",  color: "bg-violet-500" },
    { title: "Hourly Orders",   value: "32",      sub: "Peak: 12:00",       icon: Clock,          trend: "up" as const,   trendVal: "+4",    color: "bg-sky-500" },
    { title: "Weekly Orders",   value: "1,132",   sub: "This week",         icon: Calendar,       trend: "down" as const, trendVal: "-3.1%", color: "bg-indigo-500" },
    { title: "Monthly Orders",  value: "4,200",   sub: "July 2026",         icon: BarChart2,      trend: "up" as const,   trendVal: "+5.6%", color: "bg-purple-500" },
    { title: "Active Drivers",  value: "4",       sub: "2 inactive",        icon: Car,            trend: "neutral" as const, trendVal: "No change", color: "bg-emerald-500" },
    { title: "Company Profit",  value: "SAR 49.8K", sub: "July 2026",       icon: TrendingUp,     trend: "up" as const,   trendVal: "+11%",  color: "bg-green-600" },
    { title: "Total Revenue",   value: `SAR ${(totalRevenue / 1000).toFixed(1)}K`, sub: "Today",  icon: DollarSign,     trend: "up" as const,   trendVal: "+6.4%", color: "bg-teal-500" },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="max-w-[1200px] mx-auto flex flex-col gap-6">

        {/* KPI Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {kpis.map(k => <KPICard key={k.title} {...k} />)}
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-2 gap-4">
          {/* Hourly Orders */}
          <div className="bg-card rounded-xl border border-border p-5">
            <div className="flex items-center justify-between mb-5">
              <SectionTitle title="Orders by Hour" sub="Today, July 14" />
              <span className="text-xs text-muted-foreground font-mono bg-muted px-2 py-1 rounded">Live</span>
            </div>
            <ResponsiveContainer width="100%" height={160}>
              <AreaChart id="dash-hourly-area" data={hourlyData}>
                <defs>
                  <linearGradient id="gBlue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563EB" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                <XAxis dataKey="h" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} width={28} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
                <Area type="monotone" dataKey="orders" stroke="#2563EB" strokeWidth={2} fill="url(#gBlue)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Weekly */}
          <div className="bg-card rounded-xl border border-border p-5">
            <div className="flex items-center justify-between mb-5">
              <SectionTitle title="Weekly Performance" sub="Orders & Revenue" />
              <select className="text-xs text-muted-foreground bg-muted border-0 rounded px-2 py-1">
                <option>This Week</option>
              </select>
            </div>
            <ResponsiveContainer width="100%" height={160}>
              <BarChart id="dash-weekly-bar" data={weeklyData} barGap={4}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} width={28} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
                <Bar dataKey="orders" fill="#2563EB" radius={[4, 4, 0, 0]} maxBarSize={24} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Monthly + Driver Performance */}
        <div className="grid grid-cols-3 gap-4">
          <div className="col-span-2 bg-card rounded-xl border border-border p-5">
            <div className="flex items-center justify-between mb-5">
              <SectionTitle title="Monthly Revenue & Profit" sub="Jan – Jul 2026" />
            </div>
            <ResponsiveContainer width="100%" height={180}>
              <LineChart id="dash-monthly-line" data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                <XAxis dataKey="m" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} width={45} tickFormatter={v => `${(v / 1000).toFixed(0)}K`} />
                <Tooltip formatter={(v: number) => `SAR ${v.toLocaleString()}`} contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                <Line type="monotone" dataKey="revenue" stroke="#2563EB" strokeWidth={2} dot={false} name="Revenue" />
                <Line type="monotone" dataKey="profit" stroke="#10B981" strokeWidth={2} dot={false} name="Profit" />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="bg-card rounded-xl border border-border p-5">
            <div className="mb-5"><SectionTitle title="Driver Performance" sub="Orders delivered" /></div>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart id="dash-driver-bar" data={driverPerfData} layout="vertical" barGap={3}>
                <XAxis type="number" tick={{ fontSize: 10, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 11, fill: "#64748B" }} axisLine={false} tickLine={false} width={52} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
                <Bar dataKey="delivered" fill="#8B5CF6" radius={[0, 4, 4, 0]} maxBarSize={14} name="Delivered" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Orders + Quick Actions */}
        <div className="grid grid-cols-3 gap-4">
          <div className="col-span-2 bg-card rounded-xl border border-border overflow-hidden">
            <div className="flex items-center justify-between p-5 border-b border-border">
              <SectionTitle title="Recent Orders" sub="Last 8 orders today" />
              <button onClick={() => setScreen("orders")} className="text-xs text-primary font-medium hover:underline">View all</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-muted/50">
                  <tr>
                    <TableHead>Order ID</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Driver</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Time</TableHead>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {ORDERS.slice(0, 8).map(o => (
                    <tr key={o.id} className="hover:bg-muted/30 cursor-pointer" onClick={() => setScreen("order-detail")}>
                      <TableCell><span className="font-mono text-xs text-muted-foreground">{o.id}</span></TableCell>
                      <TableCell><p className="font-medium text-foreground text-xs">{o.customer}</p></TableCell>
                      <TableCell><p className="text-xs text-muted-foreground">{o.driver ?? <span className="italic text-amber-600">Unassigned</span>}</p></TableCell>
                      <TableCell><span className="font-mono font-medium text-xs">SAR {o.amount}</span></TableCell>
                      <TableCell><StatusBadge status={o.status} /></TableCell>
                      <TableCell><span className="text-xs text-muted-foreground">{o.createdAt.split(" ")[1]}</span></TableCell>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Quick Actions + Notifications */}
          <div className="flex flex-col gap-4">
            <div className="bg-card rounded-xl border border-border p-5">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">Quick Actions</p>
              <div className="flex flex-col gap-2">
                <button onClick={() => openModal("new-order")} className="flex items-center gap-3 px-4 py-3 rounded-xl bg-primary text-white text-sm font-medium hover:bg-blue-700 transition-colors">
                  <Plus size={16} /> New Order
                </button>
                <button onClick={() => setScreen("drivers")} className="flex items-center gap-3 px-4 py-3 rounded-xl bg-muted text-foreground text-sm font-medium hover:bg-secondary transition-colors">
                  <Car size={16} /> Manage Drivers
                </button>
                <button onClick={() => setScreen("reports")} className="flex items-center gap-3 px-4 py-3 rounded-xl bg-muted text-foreground text-sm font-medium hover:bg-secondary transition-colors">
                  <FileText size={16} /> View Reports
                </button>
                <button className="flex items-center gap-3 px-4 py-3 rounded-xl bg-muted text-foreground text-sm font-medium hover:bg-secondary transition-colors">
                  <Download size={16} /> Export CSV
                </button>
              </div>
            </div>

            <div className="bg-card rounded-xl border border-border p-5 flex-1">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">Notifications</p>
              <div className="flex flex-col gap-3">
                {[
                  { c: "bg-emerald-500", t: "ORD-2470 delivered", s: "2 min ago", i: CheckCircle2 },
                  { c: "bg-amber-500",   t: "ORD-2471 awaiting driver", s: "5 min ago", i: AlertCircle },
                  { c: "bg-blue-500",    t: "Khalid Hassan assigned", s: "8 min ago", i: UserCheck },
                  { c: "bg-red-500",     t: "ORD-2465 cancelled", s: "14 min ago", i: XCircle },
                ].map(({ c, t, s, i: Icon }) => (
                  <div key={t} className="flex items-start gap-3">
                    <div className={cn("w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0", c)}>
                      <Icon size={13} className="text-white" />
                    </div>
                    <div>
                      <p className="text-xs font-medium text-foreground">{t}</p>
                      <p className="text-[10px] text-muted-foreground">{s}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Orders Screen ────────────────────────────────────────────────────────────
function OrdersScreen({ setScreen, openModal }: { setScreen: (s: Screen) => void; openModal: (m: Modal) => void }) {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [page, setPage] = useState(1);
  const PER_PAGE = 8;

  const filtered = useMemo(() => ORDERS.filter(o =>
    (statusFilter === "all" || o.status === statusFilter) &&
    (o.customer.toLowerCase().includes(search.toLowerCase()) || o.id.includes(search))
  ), [search, statusFilter]);

  const paginated = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="max-w-[1200px] mx-auto flex flex-col gap-4">
        {/* Filters */}
        <div className="bg-card rounded-xl border border-border p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} placeholder="Search by customer name or order ID…" className="w-full pl-9 pr-4 py-2 rounded-lg border border-border bg-background text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <div className="flex items-center gap-2">
              {(["all", "pending", "assigned", "delivered", "cancelled"] as const).map(s => (
                <button key={s} onClick={() => { setStatusFilter(s); setPage(1); }} className={cn("px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-colors", statusFilter === s ? "bg-primary text-white" : "bg-muted text-muted-foreground hover:bg-secondary")}>
                  {s === "all" ? "All" : statusCfg[s as OrderStatus]?.label ?? s}
                </button>
              ))}
            </div>
            <div className="ml-auto flex gap-2">
              <BtnSecondary icon={Download}>Export</BtnSecondary>
              <BtnPrimary icon={Plus} onClick={() => openModal("new-order")}>New Order</BtnPrimary>
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="bg-card rounded-xl border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/50 border-b border-border">
                <tr>
                  <TableHead className="w-[100px]">Order ID</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Address</TableHead>
                  <TableHead>Driver</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="w-[80px]">Actions</TableHead>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {paginated.length === 0 ? (
                  <tr><td colSpan={9}><EmptyState icon={Package} title="No orders found" sub="Try adjusting your search or filters" /></td></tr>
                ) : paginated.map(o => (
                  <tr key={o.id} className="hover:bg-muted/30 group">
                    <TableCell><span className="font-mono text-xs text-primary font-medium">{o.id}</span></TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Avatar name={o.customer} size="sm" />
                        <span className="text-xs font-medium text-foreground">{o.customer}</span>
                      </div>
                    </TableCell>
                    <TableCell><span className="text-xs text-muted-foreground font-mono">{o.phone}</span></TableCell>
                    <TableCell><p className="text-xs text-muted-foreground max-w-[180px] truncate">{o.address}</p></TableCell>
                    <TableCell>
                      {o.driver ? <span className="text-xs text-foreground">{o.driver}</span> : <span className="text-xs text-amber-600 italic font-medium">Unassigned</span>}
                    </TableCell>
                    <TableCell><span className="font-mono text-xs font-semibold">SAR {o.amount}</span></TableCell>
                    <TableCell><StatusBadge status={o.status} /></TableCell>
                    <TableCell><span className="text-xs text-muted-foreground font-mono">{o.createdAt}</span></TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => setScreen("order-detail")} className="w-7 h-7 rounded hover:bg-muted flex items-center justify-center"><Eye size={14} className="text-muted-foreground" /></button>
                        <button onClick={() => openModal("update-status")} className="w-7 h-7 rounded hover:bg-muted flex items-center justify-center"><RefreshCw size={14} className="text-muted-foreground" /></button>
                        <button onClick={() => openModal("confirm-cancel")} className="w-7 h-7 rounded hover:bg-red-50 flex items-center justify-center"><XCircle size={14} className="text-red-500" /></button>
                      </div>
                    </TableCell>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filtered.length > PER_PAGE && <Pagination page={page} total={filtered.length} perPage={PER_PAGE} onChange={setPage} />}
        </div>
      </div>
    </div>
  );
}

// ─── Order Detail Screen ──────────────────────────────────────────────────────
function OrderDetailScreen({ onBack, openModal }: { onBack: () => void; openModal: (m: Modal) => void }) {
  const o = ORDERS[1];
  const driver = DRIVERS.find(d => d.id === o.driverId);
  const timeline = [
    { status: "Order Placed",    time: "10:32 AM", done: true },
    { status: "Driver Assigned", time: "10:35 AM", done: true },
    { status: "Picked Up",       time: "10:52 AM", done: false },
    { status: "Out for Delivery",time: "—",        done: false },
    { status: "Delivered",       time: "—",        done: false },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="max-w-[1100px] mx-auto flex flex-col gap-5">
        {/* Actions bar */}
        <div className="flex items-center gap-3 flex-wrap">
          <StatusBadge status={o.status} />
          <span className="font-mono text-sm font-semibold text-foreground">{o.id}</span>
          <div className="ml-auto flex gap-2 flex-wrap">
            <BtnSecondary icon={Printer}>Print</BtnSecondary>
            <BtnSecondary icon={Copy}>Duplicate</BtnSecondary>
            <BtnSecondary icon={Pencil} onClick={() => openModal("edit-order")}>Edit</BtnSecondary>
            <button onClick={() => openModal("update-status")} className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white text-sm font-medium rounded-lg hover:bg-emerald-700 transition-colors">
              <CheckCircle2 size={15} /> Mark Delivered
            </button>
            <BtnDanger onClick={() => openModal("confirm-cancel")}>Cancel Order</BtnDanger>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          {/* Left: Customer + Order */}
          <div className="col-span-2 flex flex-col gap-4">
            {/* Customer Info */}
            <div className="bg-card rounded-xl border border-border p-5">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">Customer Information</p>
              <div className="flex items-start gap-4">
                <Avatar name={o.customer} size="lg" />
                <div className="grid grid-cols-2 gap-x-8 gap-y-3 flex-1">
                  {[
                    ["Full Name", o.customer],
                    ["Phone", o.phone],
                    ["Delivery Address", o.address],
                    ["Notes", o.notes || "—"],
                  ].map(([l, v]) => (
                    <div key={l}>
                      <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider">{l}</p>
                      <p className="text-sm text-foreground mt-0.5">{v}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Order Info */}
            <div className="bg-card rounded-xl border border-border p-5">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">Order Information</p>
              <div className="grid grid-cols-3 gap-4">
                {[
                  ["Order ID", o.id, true],
                  ["Amount", `SAR ${o.amount}`, true],
                  ["Status", statusCfg[o.status].label, false],
                  ["Created At", o.createdAt, false],
                  ["Driver", o.driver ?? "Unassigned", false],
                  ["Driver ID", o.driverId ?? "—", true],
                ].map(([l, v, mono]) => (
                  <div key={String(l)}>
                    <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider">{l}</p>
                    <p className={cn("text-sm text-foreground mt-0.5", mono ? "font-mono" : "")}>{String(v)}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Timeline */}
            <div className="bg-card rounded-xl border border-border p-5">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">Order Timeline</p>
              <div className="flex flex-col gap-0">
                {timeline.map((t, i) => (
                  <div key={t.status} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className={cn("w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 z-10", t.done ? "bg-primary" : "bg-muted border-2 border-border")}>
                        {t.done ? <Check size={13} className="text-white" /> : <Circle size={10} className="text-muted-foreground" />}
                      </div>
                      {i < timeline.length - 1 && <div className={cn("w-0.5 flex-1 my-1", t.done ? "bg-primary" : "bg-border")} style={{ minHeight: 24 }} />}
                    </div>
                    <div className="pb-5">
                      <p className={cn("text-sm font-medium", t.done ? "text-foreground" : "text-muted-foreground")}>{t.status}</p>
                      <p className="text-xs text-muted-foreground">{t.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Driver + Update Status */}
          <div className="flex flex-col gap-4">
            {/* Driver */}
            <div className="bg-card rounded-xl border border-border p-5">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">Assigned Driver</p>
              {driver ? (
                <div className="flex flex-col gap-4">
                  <div className="flex items-center gap-3">
                    <Avatar name={driver.name} size="lg" />
                    <div>
                      <p className="font-semibold text-sm text-foreground">{driver.name}</p>
                      <DriverBadge status={driver.status} />
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 text-xs">
                    {[
                      [Phone, driver.phone],
                      [Car, `${driver.vehicleType} • ${driver.vehiclePlate}`],
                      [Star, `${driver.rating} rating`],
                    ].map(([Icon, val], i) => (
                      <div key={i} className="flex items-center gap-2 text-muted-foreground">
                        <Icon size={13} className="text-muted-foreground flex-shrink-0" />
                        <span>{String(val)}</span>
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-2 mt-1">
                    <div className="bg-muted rounded-lg p-3 text-center">
                      <p className="text-lg font-bold text-foreground">{driver.ordersDelivered}</p>
                      <p className="text-[10px] text-muted-foreground">Delivered</p>
                    </div>
                    <div className="bg-muted rounded-lg p-3 text-center">
                      <p className="text-lg font-bold text-foreground">{driver.currentOrders}</p>
                      <p className="text-[10px] text-muted-foreground">Active</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-4">
                  <Car size={24} className="text-muted-foreground mx-auto mb-2" />
                  <p className="text-xs text-muted-foreground">No driver assigned yet</p>
                  <button onClick={() => openModal("update-status")} className="mt-3 px-4 py-2 bg-primary text-white text-xs font-medium rounded-lg hover:bg-blue-700 transition-colors">
                    Assign Driver
                  </button>
                </div>
              )}
            </div>

            {/* Update Status */}
            <div className="bg-card rounded-xl border border-border p-5">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Update Status</p>
              <button onClick={() => openModal("update-status")} className="w-full flex items-center justify-center gap-2 py-2.5 border-2 border-dashed border-border rounded-xl text-sm text-muted-foreground hover:border-primary hover:text-primary transition-colors">
                <RefreshCw size={15} /> Change Status
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Drivers Screen ───────────────────────────────────────────────────────────
function DriversScreen({ setScreen, openModal }: { setScreen: (s: Screen) => void; openModal: (m: Modal) => void }) {
  const [view, setView] = useState<"table" | "grid">("table");
  const [search, setSearch] = useState("");
  const [statusF, setStatusF] = useState("all");

  const filtered = useMemo(() => DRIVERS.filter(d =>
    (statusF === "all" || d.status === statusF) &&
    d.name.toLowerCase().includes(search.toLowerCase())
  ), [search, statusF]);

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="max-w-[1200px] mx-auto flex flex-col gap-4">
        <div className="bg-card rounded-xl border border-border p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search drivers…" className="w-full pl-9 pr-4 py-2 rounded-lg border border-border bg-background text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <div className="flex gap-2">
              {["all", "active", "busy", "inactive"].map(s => (
                <button key={s} onClick={() => setStatusF(s)} className={cn("px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-colors", statusF === s ? "bg-primary text-white" : "bg-muted text-muted-foreground hover:bg-secondary")}>
                  {s === "all" ? "All" : driverStatusCfg[s as DriverStatus]?.label ?? s}
                </button>
              ))}
            </div>
            <div className="ml-auto flex gap-2 items-center">
              <div className="flex gap-1 bg-muted rounded-lg p-1">
                <button onClick={() => setView("table")} className={cn("w-7 h-7 rounded flex items-center justify-center", view === "table" ? "bg-card shadow-sm" : "")}><List size={14} /></button>
                <button onClick={() => setView("grid")} className={cn("w-7 h-7 rounded flex items-center justify-center", view === "grid" ? "bg-card shadow-sm" : "")}><LayoutGrid size={14} /></button>
              </div>
              <BtnPrimary icon={Plus} onClick={() => openModal("new-driver")}>Add Driver</BtnPrimary>
            </div>
          </div>
        </div>

        {view === "table" ? (
          <div className="bg-card rounded-xl border border-border overflow-hidden">
            <table className="w-full">
              <thead className="bg-muted/50 border-b border-border">
                <tr>
                  <TableHead>Driver</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Vehicle</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Delivered</TableHead>
                  <TableHead>Active</TableHead>
                  <TableHead>Commission</TableHead>
                  <TableHead>Profit (SAR)</TableHead>
                  <TableHead>Rating</TableHead>
                  <TableHead className="w-[80px]">Actions</TableHead>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map(d => (
                  <tr key={d.id} className="hover:bg-muted/30 group cursor-pointer" onClick={() => setScreen("driver-detail")}>
                    <TableCell>
                      <div className="flex items-center gap-2.5">
                        <Avatar name={d.name} size="sm" />
                        <div>
                          <p className="text-xs font-medium text-foreground">{d.name}</p>
                          <p className="text-[10px] font-mono text-muted-foreground">{d.id}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell><span className="text-xs font-mono text-muted-foreground">{d.phone}</span></TableCell>
                    <TableCell><span className="text-xs text-muted-foreground">{d.vehicleType} · {d.vehiclePlate}</span></TableCell>
                    <TableCell><DriverBadge status={d.status} /></TableCell>
                    <TableCell><span className="text-xs font-mono font-semibold">{d.ordersDelivered}</span></TableCell>
                    <TableCell><span className="text-xs font-mono">{d.currentOrders}</span></TableCell>
                    <TableCell><span className="text-xs font-mono">{d.commission}%</span></TableCell>
                    <TableCell><span className="text-xs font-mono font-semibold">{d.totalProfit.toLocaleString()}</span></TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Star size={11} className="text-amber-400 fill-amber-400" />
                        <span className="text-xs font-medium">{d.rating}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="w-7 h-7 rounded hover:bg-muted flex items-center justify-center" onClick={e => { e.stopPropagation(); setScreen("driver-detail"); }}><Eye size={13} className="text-muted-foreground" /></button>
                        <button className="w-7 h-7 rounded hover:bg-muted flex items-center justify-center" onClick={e => { e.stopPropagation(); openModal("edit-driver"); }}><Pencil size={13} className="text-muted-foreground" /></button>
                        <button className="w-7 h-7 rounded hover:bg-red-50 flex items-center justify-center" onClick={e => { e.stopPropagation(); openModal("confirm-delete-driver"); }}><Trash2 size={13} className="text-red-500" /></button>
                      </div>
                    </TableCell>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-4">
            {filtered.map(d => (
              <div key={d.id} onClick={() => setScreen("driver-detail")} className="bg-card rounded-xl border border-border p-5 hover:shadow-md cursor-pointer transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <Avatar name={d.name} size="lg" />
                    <div>
                      <p className="font-semibold text-sm text-foreground">{d.name}</p>
                      <p className="text-xs text-muted-foreground">{d.vehicleType} · {d.vehiclePlate}</p>
                    </div>
                  </div>
                  <DriverBadge status={d.status} />
                </div>
                <div className="grid grid-cols-3 gap-2 mt-3">
                  {[["Orders", d.ordersDelivered], ["Active", d.currentOrders], ["Rating", d.rating]].map(([l, v]) => (
                    <div key={String(l)} className="bg-muted rounded-lg p-2.5 text-center">
                      <p className="text-sm font-bold text-foreground">{v}</p>
                      <p className="text-[10px] text-muted-foreground">{l}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-3 pt-3 border-t border-border flex items-center justify-between">
                  <span className="text-xs text-muted-foreground font-mono">{d.phone}</span>
                  <span className="text-xs font-mono font-semibold text-foreground">SAR {d.totalProfit.toLocaleString()}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Driver Detail Screen ─────────────────────────────────────────────────────
function DriverDetailScreen({ onBack, openModal }: { onBack: () => void; openModal: (m: Modal) => void }) {
  const d = DRIVERS[0];
  const driverOrders = ORDERS.filter(o => o.driverId === d.id);
  const [perfPeriod, setPerfPeriod] = useState("weekly");

  const perfData = {
    hourly: hourlyData.map(h => ({ label: h.h + ":00", orders: Math.round(h.orders * 0.3) })),
    weekly: weeklyData.map(w => ({ label: w.day, orders: Math.round(w.orders * 0.3) })),
    monthly: monthlyData.map(m => ({ label: m.m, orders: Math.round(m.orders * 0.03) })),
  }[perfPeriod] ?? [];

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="max-w-[1100px] mx-auto flex flex-col gap-5">
        {/* Header */}
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-start gap-5">
            <Avatar name={d.name} size="lg" />
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-1">
                <h2 className="text-lg font-bold text-foreground">{d.name}</h2>
                <DriverBadge status={d.status} />
                <div className="flex items-center gap-1 ml-1">
                  <Star size={13} className="text-amber-400 fill-amber-400" />
                  <span className="text-sm font-semibold">{d.rating}</span>
                </div>
              </div>
              <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><Phone size={12} />{d.phone}</span>
                <span className="flex items-center gap-1"><MapPin size={12} />{d.address}</span>
                <span className="flex items-center gap-1"><Car size={12} />{d.vehicleType} · {d.vehiclePlate}</span>
                <span className="flex items-center gap-1"><Hash size={12} />{d.nationalId}</span>
                <span className="flex items-center gap-1"><Calendar size={12} />Joined {d.joinedDate}</span>
              </div>
            </div>
            <div className="flex gap-2">
              <BtnSecondary icon={Pencil} onClick={() => openModal("edit-driver")}>Edit</BtnSecondary>
              <BtnDanger onClick={() => openModal("confirm-delete-driver")}>Deactivate</BtnDanger>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4">
          {[
            { label: "Total Delivered", value: d.ordersDelivered, sub: "All time", color: "bg-blue-500", icon: CheckCircle2 },
            { label: "Active Orders", value: d.currentOrders, sub: "Right now", color: "bg-violet-500", icon: Package },
            { label: "Total Revenue", value: `SAR ${d.totalProfit.toLocaleString()}`, sub: "Company profit", color: "bg-emerald-500", icon: DollarSign },
            { label: "Driver Profit", value: `SAR ${d.driverProfit.toLocaleString()}`, sub: `${d.commission}% commission`, color: "bg-amber-500", icon: TrendingUp },
          ].map(s => <KPICard key={s.label} title={s.label} value={String(s.value)} sub={s.sub} icon={s.icon} color={s.color} />)}
        </div>

        <div className="grid grid-cols-3 gap-4">
          {/* Performance chart */}
          <div className="col-span-2 bg-card rounded-xl border border-border p-5">
            <div className="flex items-center justify-between mb-5">
              <SectionTitle title="Delivery Performance" />
              <div className="flex gap-1 bg-muted rounded-lg p-1">
                {["hourly", "weekly", "monthly"].map(p => (
                  <button key={p} onClick={() => setPerfPeriod(p)} className={cn("px-3 py-1 rounded-md text-xs font-medium capitalize transition-colors", perfPeriod === p ? "bg-card shadow-sm text-foreground" : "text-muted-foreground")}>
                    {p}
                  </button>
                ))}
              </div>
            </div>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart id="driver-perf-bar" data={perfData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} width={24} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
                <Bar dataKey="orders" fill="#2563EB" radius={[4, 4, 0, 0]} maxBarSize={32} name="Orders" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Activity log */}
          <div className="bg-card rounded-xl border border-border p-5">
            <div className="mb-4"><SectionTitle title="Activity History" /></div>
            <div className="flex flex-col gap-3">
              {driverOrders.slice(0, 5).map(o => (
                <div key={o.id} className="flex items-center gap-3">
                  <StatusBadge status={o.status} />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">{o.customer}</p>
                    <p className="text-[10px] font-mono text-muted-foreground">{o.id}</p>
                  </div>
                  <span className="text-xs font-mono font-semibold text-foreground">SAR {o.amount}</span>
                </div>
              ))}
              {driverOrders.length === 0 && <p className="text-xs text-muted-foreground text-center py-4">No orders yet</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Reports Screen ───────────────────────────────────────────────────────────
function ReportsScreen() {
  const [period, setPeriod] = useState("today");
  const periods = ["Today", "Yesterday", "This Week", "This Month", "Custom Range"];
  const statusCounts = {
    delivered: ORDERS.filter(o => o.status === "delivered").length,
    cancelled: ORDERS.filter(o => o.status === "cancelled").length,
    pending:   ORDERS.filter(o => o.status === "pending").length,
    assigned:  ORDERS.filter(o => o.status === "assigned").length,
  };
  const pieData = Object.entries(statusCounts).map(([k, v]) => ({ name: statusCfg[k as OrderStatus].label, value: v }));

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="max-w-[1200px] mx-auto flex flex-col gap-5">
        {/* Period selector */}
        <div className="bg-card rounded-xl border border-border p-4">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex gap-1 bg-muted rounded-lg p-1">
              {periods.map(p => (
                <button key={p} onClick={() => setPeriod(p.toLowerCase())} className={cn("px-3 py-1.5 rounded-md text-xs font-medium transition-colors", period === p.toLowerCase() ? "bg-card shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground")}>
                  {p}
                </button>
              ))}
            </div>
            <div className="ml-auto flex gap-2">
              <BtnSecondary icon={FileDown}>Export PDF</BtnSecondary>
              <BtnSecondary icon={Download}>Export Excel</BtnSecondary>
              <BtnSecondary icon={Printer}>Print</BtnSecondary>
            </div>
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-4 gap-4">
          {[
            { title: "Completed Orders", value: String(statusCounts.delivered), icon: CheckCircle2, color: "bg-emerald-500", trend: "up" as const, trendVal: "+14%" },
            { title: "Cancelled Orders", value: String(statusCounts.cancelled), icon: XCircle, color: "bg-red-500", trend: "down" as const, trendVal: "-2%" },
            { title: "Total Revenue", value: "SAR 2,730", icon: DollarSign, color: "bg-blue-500", trend: "up" as const, trendVal: "+8%" },
            { title: "Avg. Order Value", value: "SAR 227", icon: TrendingUp, color: "bg-violet-500", trend: "up" as const, trendVal: "+3%" },
          ].map(k => <KPICard key={k.title} {...k} />)}
        </div>

        {/* Charts row */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-card rounded-xl border border-border p-5">
            <div className="mb-4"><SectionTitle title="Orders by Hour" sub="Volume distribution" /></div>
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart id="rep-hourly-area" data={hourlyData}>
                <defs>
                  <linearGradient id="gRep" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                <XAxis dataKey="h" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} width={24} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
                <Area type="monotone" dataKey="orders" stroke="#8B5CF6" strokeWidth={2} fill="url(#gRep)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-card rounded-xl border border-border p-5">
            <div className="mb-4"><SectionTitle title="Order Status Breakdown" sub="Today" /></div>
            <div className="flex items-center gap-6">
              <ResponsiveContainer width="100%" height={180}>
                <PieChart id="rep-status-pie">
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                    {pieData.map((_, i) => <Cell key={i} fill={pieColors[i % pieColors.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
                  <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-card rounded-xl border border-border p-5">
            <div className="mb-4"><SectionTitle title="Monthly Revenue & Profit" sub="Jan – Jul 2026" /></div>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart id="rep-monthly-bar" data={monthlyData} barGap={4}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
                <XAxis dataKey="m" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} width={45} tickFormatter={v => `${(v / 1000).toFixed(0)}K`} />
                <Tooltip formatter={(v: number) => `SAR ${v.toLocaleString()}`} contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="revenue" fill="#2563EB" radius={[4, 4, 0, 0]} maxBarSize={20} name="Revenue" />
                <Bar dataKey="profit" fill="#10B981" radius={[4, 4, 0, 0]} maxBarSize={20} name="Profit" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Driver ranking */}
          <div className="bg-card rounded-xl border border-border p-5">
            <div className="mb-4"><SectionTitle title="Driver Ranking" sub="By deliveries" /></div>
            <div className="flex flex-col gap-2">
              {[...DRIVERS].sort((a, b) => b.ordersDelivered - a.ordersDelivered).map((d, i) => (
                <div key={d.id} className="flex items-center gap-3">
                  <span className={cn("w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0", i === 0 ? "bg-amber-100 text-amber-700" : i === 1 ? "bg-slate-100 text-slate-600" : i === 2 ? "bg-orange-50 text-orange-700" : "bg-muted text-muted-foreground")}>
                    {i + 1}
                  </span>
                  <Avatar name={d.name} size="sm" />
                  <span className="text-xs font-medium text-foreground flex-1">{d.name}</span>
                  <div className="flex items-center gap-2">
                    <div className="w-24 h-1.5 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-primary rounded-full" style={{ width: `${(d.ordersDelivered / 201) * 100}%` }} />
                    </div>
                    <span className="text-xs font-mono font-semibold text-foreground w-8 text-right">{d.ordersDelivered}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Settings Screen ──────────────────────────────────────────────────────────
function SettingsScreen({ dark, onToggleDark }: { dark: boolean; onToggleDark: () => void }) {
  const [tab, setTab] = useState("general");
  const tabs = [
    { id: "general",  label: "General",  icon: Building2 },
    { id: "users",    label: "Users",    icon: Users },
    { id: "security", label: "Security", icon: Shield },
    { id: "notifications", label: "Notifications", icon: BellIcon },
    { id: "backup",   label: "Backup",   icon: Database },
    { id: "theme",    label: "Theme",    icon: Layers },
    { id: "about",    label: "About",    icon: Info },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="max-w-[900px] mx-auto flex gap-6">
        {/* Sidebar tabs */}
        <div className="w-[180px] flex-shrink-0">
          <nav className="flex flex-col gap-1 sticky top-0">
            {tabs.map(({ id, label, icon: Icon }) => (
              <button key={id} onClick={() => setTab(id)} className={cn("flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium text-left transition-colors", tab === id ? "bg-accent text-primary" : "text-muted-foreground hover:bg-muted hover:text-foreground")}>
                <Icon size={15} />
                {label}
              </button>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col gap-5">
          {tab === "general" && (
            <>
              <div className="bg-card rounded-xl border border-border p-6">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-5">Company Information</p>
                <div className="grid grid-cols-2 gap-4">
                  <FormRow label="Company Name"><Input value="Al-Amal Delivery Co." /></FormRow>
                  <FormRow label="Commission %" required><Input value="18" mono /></FormRow>
                  <FormRow label="Email"><Input type="email" value="admin@alamal-delivery.sa" /></FormRow>
                  <FormRow label="Phone"><Input value="+966 11 234 5678" mono /></FormRow>
                  <div className="col-span-2"><FormRow label="Address"><Input value="King Fahd Road, Al-Olaya, Riyadh 12212" /></FormRow></div>
                </div>
              </div>
              <div className="bg-card rounded-xl border border-border p-6">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-5">Business Hours</p>
                <div className="grid grid-cols-2 gap-4">
                  <FormRow label="Opening Time"><Input value="08:00 AM" mono /></FormRow>
                  <FormRow label="Closing Time"><Input value="11:00 PM" mono /></FormRow>
                  <FormRow label="Language">
                    <Select value="en"><option value="en">English</option><option value="ar">Arabic (العربية)</option></Select>
                  </FormRow>
                  <FormRow label="Timezone">
                    <Select><option>Asia/Riyadh (UTC+3)</option></Select>
                  </FormRow>
                </div>
              </div>
              <div className="flex justify-end">
                <BtnPrimary icon={Check}>Save Changes</BtnPrimary>
              </div>
            </>
          )}

          {tab === "users" && (
            <div className="bg-card rounded-xl border border-border overflow-hidden">
              <div className="flex items-center justify-between p-5 border-b border-border">
                <SectionTitle title="User Management" sub="Manage system access and permissions" />
                <BtnPrimary icon={Plus}>Add User</BtnPrimary>
              </div>
              <table className="w-full">
                <thead className="bg-muted/50 border-b border-border">
                  <tr>
                    <TableHead>Name</TableHead><TableHead>Email</TableHead>
                    <TableHead>Role</TableHead><TableHead>Status</TableHead><TableHead>Actions</TableHead>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {[
                    { name: "Nasser Al-Qahtani", email: "nasser@company.sa", role: "Manager", status: "active" },
                    { name: "Rima Khalid", email: "rima@company.sa", role: "Supervisor", status: "active" },
                    { name: "Faris Al-Ahmadi", email: "faris@company.sa", role: "Dispatcher", status: "inactive" },
                  ].map(u => (
                    <tr key={u.email} className="hover:bg-muted/30">
                      <TableCell><div className="flex items-center gap-2.5"><Avatar name={u.name} size="sm" /><span className="text-xs font-medium text-foreground">{u.name}</span></div></TableCell>
                      <TableCell><span className="text-xs text-muted-foreground font-mono">{u.email}</span></TableCell>
                      <TableCell><span className="text-xs px-2 py-1 bg-accent text-accent-foreground rounded-full">{u.role}</span></TableCell>
                      <TableCell><span className={cn("text-xs px-2 py-1 rounded-full border", u.status === "active" ? "bg-emerald-50 text-emerald-700 border-emerald-200" : "bg-muted text-muted-foreground border-border")}>{u.status}</span></TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <button className="w-7 h-7 rounded hover:bg-muted flex items-center justify-center"><Pencil size={13} className="text-muted-foreground" /></button>
                          <button className="w-7 h-7 rounded hover:bg-red-50 flex items-center justify-center"><Trash2 size={13} className="text-red-500" /></button>
                        </div>
                      </TableCell>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {tab === "security" && (
            <div className="flex flex-col gap-4">
              <div className="bg-card rounded-xl border border-border p-6">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-5">Change Password</p>
                <div className="flex flex-col gap-4 max-w-sm">
                  <FormRow label="Current Password"><Input type="password" placeholder="••••••••••" /></FormRow>
                  <FormRow label="New Password"><Input type="password" placeholder="••••••••••" /></FormRow>
                  <FormRow label="Confirm New Password"><Input type="password" placeholder="••••••••••" /></FormRow>
                  <BtnPrimary icon={Lock}>Update Password</BtnPrimary>
                </div>
              </div>
              <div className="bg-card rounded-xl border border-border p-6">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-5">Two-Factor Authentication</p>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-foreground">Authenticator App</p>
                    <p className="text-xs text-muted-foreground">Use an app to generate one-time codes</p>
                  </div>
                  <button className="px-3 py-1.5 bg-primary text-white text-xs font-medium rounded-lg hover:bg-blue-700 transition-colors">Enable</button>
                </div>
              </div>
            </div>
          )}

          {tab === "notifications" && (
            <div className="bg-card rounded-xl border border-border p-6">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-5">Notification Preferences</p>
              <div className="flex flex-col gap-4">
                {[
                  ["New Order Received", "Get notified when a new order is placed"],
                  ["Order Delivered", "Alert when an order is successfully delivered"],
                  ["Order Cancelled", "Alert when an order is cancelled"],
                  ["Driver Status Change", "When a driver goes on/off duty"],
                  ["Daily Report", "Receive a daily summary at end of day"],
                  ["Weekly Report", "Receive a weekly performance report"],
                ].map(([title, sub]) => (
                  <div key={String(title)} className="flex items-center justify-between py-3 border-b border-border last:border-0">
                    <div>
                      <p className="text-sm font-medium text-foreground">{title}</p>
                      <p className="text-xs text-muted-foreground">{sub}</p>
                    </div>
                    <div className="w-10 h-5 rounded-full bg-primary relative cursor-pointer">
                      <div className="absolute right-0.5 top-0.5 w-4 h-4 rounded-full bg-white shadow-sm" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === "backup" && (
            <div className="flex flex-col gap-4">
              <div className="bg-card rounded-xl border border-border p-6">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-5">Database Backup</p>
                <div className="flex flex-col gap-4">
                  <div className="rounded-xl bg-muted p-4 flex items-start gap-3">
                    <Info size={16} className="text-muted-foreground flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-muted-foreground">Last backup: <span className="font-semibold text-foreground">July 14, 2026 at 03:00 AM</span> — Automatic daily backup enabled</p>
                  </div>
                  <div className="flex gap-3">
                    <BtnPrimary icon={Database}>Create Backup Now</BtnPrimary>
                    <BtnSecondary icon={UploadCloud}>Restore from Backup</BtnSecondary>
                  </div>
                </div>
              </div>
            </div>
          )}

          {tab === "theme" && (
            <div className="bg-card rounded-xl border border-border p-6">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Theme</p>
              <p className="text-xs text-muted-foreground mb-5">Choose your preferred color scheme</p>
              <div className="grid grid-cols-2 gap-4">
                {([
                  { label: "Light", isDark: false },
                  { label: "Dark", isDark: true },
                ] as const).map(({ label, isDark }) => {
                  const active = dark === isDark;
                  return (
                    <button
                      key={label}
                      onClick={() => { if (!active) onToggleDark(); }}
                      className={cn(
                        "p-4 rounded-xl border-2 text-sm font-medium flex flex-col gap-3 transition-all",
                        active ? "border-primary bg-accent text-primary shadow-sm" : "border-border hover:border-primary/40 text-muted-foreground"
                      )}
                    >
                      <div className={cn("w-full h-20 rounded-lg flex items-end p-3 gap-2 overflow-hidden",
                        isDark ? "bg-[#0F0A1E]" : "bg-[#F9F7FF] border border-border"
                      )}>
                        <div className={cn("h-7 flex-1 rounded", isDark ? "bg-[#1A1033]" : "bg-white border border-border")} />
                        <div className={cn("h-5 w-10 rounded", isDark ? "bg-[#A78BFA]" : "bg-[#6D28D9]")} />
                      </div>
                      <div className="flex items-center justify-between">
                        <span>{label} Mode</span>
                        {active && (
                          <span className="flex items-center gap-1 text-xs font-normal text-primary">
                            <Check size={12} /> Active
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {tab === "about" && (
            <div className="bg-card rounded-xl border border-border p-6 flex flex-col gap-4">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-xl bg-primary flex items-center justify-center">
                  <Truck size={24} className="text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-foreground">DeliverOS</h3>
                  <p className="text-xs text-muted-foreground">Delivery Management System</p>
                  <p className="text-xs font-mono text-muted-foreground mt-0.5">Version 2.4.1 — Build 20260714</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 text-xs text-muted-foreground pt-2 border-t border-border">
                {[["License", "Enterprise"], ["Support", "24/7"], ["Region", "Saudi Arabia"], ["Language", "English / Arabic"]].map(([k, v]) => (
                  <div key={k}><span className="font-medium text-foreground">{k}:</span> {v}</div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Profile Screen ────────────────────────────────────────────────────────────
function ProfileScreen({ onLogout }: { onLogout: () => void }) {
  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="max-w-[700px] mx-auto flex flex-col gap-5">
        {/* Profile header */}
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-center gap-5">
            <div className="relative">
              <Avatar name="Nasser Al-Qahtani" size="lg" />
              <button className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center hover:bg-blue-700 transition-colors">
                <Pencil size={10} />
              </button>
            </div>
            <div>
              <h2 className="text-base font-bold text-foreground">Nasser Al-Qahtani</h2>
              <p className="text-xs text-muted-foreground">System Manager · Al-Amal Delivery Co.</p>
              <p className="text-xs font-mono text-muted-foreground mt-0.5">nasser@alamal-delivery.sa</p>
            </div>
          </div>
        </div>

        {/* Profile form */}
        <div className="bg-card rounded-xl border border-border p-6">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-5">Profile Information</p>
          <div className="grid grid-cols-2 gap-4">
            <FormRow label="First Name"><Input value="Nasser" /></FormRow>
            <FormRow label="Last Name"><Input value="Al-Qahtani" /></FormRow>
            <FormRow label="Email"><Input type="email" value="nasser@alamal-delivery.sa" /></FormRow>
            <FormRow label="Phone"><Input value="+966 50 000 1111" mono /></FormRow>
            <FormRow label="Role"><Input value="System Manager" /></FormRow>
            <FormRow label="Language">
              <Select><option>English</option><option>Arabic (العربية)</option></Select>
            </FormRow>
          </div>
          <div className="flex justify-end mt-5">
            <BtnPrimary icon={Check}>Save Profile</BtnPrimary>
          </div>
        </div>

        {/* Change password */}
        <div className="bg-card rounded-xl border border-border p-6">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-5">Change Password</p>
          <div className="flex flex-col gap-4 max-w-sm">
            <FormRow label="Current Password"><Input type="password" placeholder="••••••••••" /></FormRow>
            <FormRow label="New Password"><Input type="password" placeholder="••••••••••" /></FormRow>
            <FormRow label="Confirm Password"><Input type="password" placeholder="••••••••••" /></FormRow>
            <BtnPrimary icon={Lock}>Update Password</BtnPrimary>
          </div>
        </div>

        {/* Logout */}
        <div className="bg-red-50 rounded-xl border border-red-100 p-5 flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-red-700">Sign out of your account</p>
            <p className="text-xs text-red-500 mt-0.5">You will need to sign in again to access the system</p>
          </div>
          <button onClick={onLogout} className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700 transition-colors">
            <LogOut size={15} /> Sign Out
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [authed, setAuthed] = useState(false);
  const [screen, setScreen] = useState<Screen>("login");
  const [modal, setModal] = useState<Modal>("none");
  const [dark, setDark] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  const openModal = (m: Modal) => setModal(m);
  const closeModal = () => setModal("none");

  const handleLogin = () => { setAuthed(true); setScreen("dashboard"); };
  const handleLogout = () => { setAuthed(false); setScreen("login"); };

  // Breadcrumb map
  const breadcrumbs: Record<string, string[]> = {
    dashboard:     ["Home", "Dashboard"],
    orders:        ["Home", "Orders"],
    "order-detail":["Home", "Orders", "Order Detail"],
    drivers:       ["Home", "Drivers"],
    "driver-detail":["Home", "Drivers", "Driver Detail"],
    reports:       ["Home", "Reports"],
    settings:      ["Home", "Settings"],
    profile:       ["Home", "Profile"],
  };

  const titles: Record<string, string> = {
    dashboard: "Dashboard", orders: "Orders", "order-detail": "Order Details",
    drivers: "Drivers", "driver-detail": "Driver Details",
    reports: "Reports", settings: "Settings", profile: "My Profile",
  };

  // Auth screens
  if (!authed) {
    if (screen === "forgot") return <div className={dark ? "dark" : ""}><ForgotScreen setScreen={setScreen} /></div>;
    return <div className={dark ? "dark" : ""}><LoginScreen onLogin={handleLogin} setScreen={setScreen} /></div>;
  }

  return (
    <div className={cn("flex h-screen bg-background overflow-hidden", dark ? "dark" : "")} style={{ fontFamily: "'DM Sans', sans-serif" }}>
      <Sidebar screen={screen} setScreen={setScreen} />

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <TopBar
          title={titles[screen] ?? screen}
          breadcrumb={breadcrumbs[screen]}
          onBack={["order-detail", "driver-detail"].includes(screen) ? () => setScreen(screen.includes("order") ? "orders" : "drivers") : undefined}
          dark={dark}
          onToggleDark={() => setDark(d => !d)}
          actions={
            screen === "orders" ? <BtnPrimary icon={Plus} onClick={() => openModal("new-order")}>New Order</BtnPrimary> :
            screen === "drivers" ? <BtnPrimary icon={Plus} onClick={() => openModal("new-driver")}>Add Driver</BtnPrimary> : undefined
          }
        />

        {screen === "dashboard"     && <DashboardScreen setScreen={setScreen} openModal={openModal} />}
        {screen === "orders"        && <OrdersScreen setScreen={setScreen} openModal={openModal} />}
        {screen === "order-detail"  && <OrderDetailScreen onBack={() => setScreen("orders")} openModal={openModal} />}
        {screen === "drivers"       && <DriversScreen setScreen={setScreen} openModal={openModal} />}
        {screen === "driver-detail" && <DriverDetailScreen onBack={() => setScreen("drivers")} openModal={openModal} />}
        {screen === "reports"       && <ReportsScreen />}
        {screen === "settings"      && <SettingsScreen dark={dark} onToggleDark={() => setDark(d => !d)} />}
        {screen === "profile"       && <ProfileScreen onLogout={handleLogout} />}
      </div>

      {/* Modals */}
      {(modal === "new-order" || modal === "new-order-voice") &&
        <NewOrderModal onClose={closeModal} preTab={modal === "new-order-voice" ? "voice" : "manual"} />}
      {modal === "new-driver" &&
        <NewDriverModal onClose={closeModal} />}
      {modal === "edit-order" &&
        <NewOrderModal onClose={closeModal} />}
      {modal === "edit-driver" &&
        <NewDriverModal onClose={closeModal} />}
      {modal === "confirm-cancel" &&
        <ConfirmDialog
          title="Cancel Order" sub="This action cannot be undone"
          message="Are you sure you want to cancel this order? The driver will be notified and the order will be marked as cancelled."
          onClose={closeModal} onConfirm={closeModal} variant="danger"
        />}
      {modal === "confirm-delete-driver" &&
        <ConfirmDialog
          title="Deactivate Driver" sub="Driver account will be suspended"
          message="This driver will be marked as inactive and cannot receive new orders. You can reactivate them later from the driver settings."
          onClose={closeModal} onConfirm={closeModal} variant="warning"
        />}
      {modal === "update-status" &&
        <UpdateStatusModal order={ORDERS[1]} onClose={closeModal} />}
    </div>
  );
}
