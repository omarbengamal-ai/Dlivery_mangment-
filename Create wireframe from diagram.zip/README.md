
  # Create wireframe from diagram

  This is a code bundle for Create wireframe from diagram. The original project is available at https://www.figma.com/design/5Byitz9NqjHYy9XpKE9cfW/Create-wireframe-from-diagram.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  